package com.example.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class FinalProject {
	@Test
	public void testtitle() {
		WebDriver dr = new FirefoxDriver();
		SoftAssert sa = new SoftAssert();
		dr.get("https://profile.w3schools.com/log-in");
		String exptitle = "Log in - W3Schools";
		String actualtitle = dr.getTitle();
		System.out.println(actualtitle);
		
		sa.assertEquals(exptitle,actualtitle);
		
		String loginButton = dr.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[4]/div[1]/div/div[4]/div[1]/button")).getText();
		String expTxt ="Log in";
		sa.assertEquals(loginButton,expTxt);
		sa.assertAll();
	}


}
