package com.example.demo;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalSpringProjectApplication {

	public static void main(String[] args) {
//		SpringApplication.run(FinalSpringProjectApplication.class, args);
	}

}
