package com.example.demo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

public class Connection {
  @Test
  public static WebDriver initializeWebDriver(String browser) {
	  WebDriver driver = null;
//	  driver connection
	  String browser1 = "firefox";
	  AssertJUnit.assertEquals(browser, browser1);
	  if("chrome".equalsIgnoreCase(browser)) {
		  driver = new ChromeDriver();
	  }else if("firefox".equalsIgnoreCase(browser)){
		  driver = new FirefoxDriver();
	  }
	  
	  return driver;
  }
}