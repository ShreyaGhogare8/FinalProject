package com.example.demo;
import org.openqa.selenium.WebDriver;

public class Main {
public static void main(String args[]) throws InterruptedException {
	String browserType ="firefox";
//	calling connection 
	WebDriver driver = Connection.initializeWebDriver(browserType);
	
	String username ="shreyaghogare11@gmail.com";
	String password ="Testing@123";
	String search = "javascript";
//	calling login 
	Login.performLogin(driver, username, password);
	Thread.sleep(5000);
// calling cart 
	Cart.searchAndCart(driver, search);
	
	
	String first ="Shreya";
	String last ="Ghogare";
	String add ="maratha nagar,akola";
	String city ="akola";
	String pin ="444444";
//	calling payment
	Payment.makePayment(driver, username, first, last, add, city, pin);
	Thread.sleep(4000);
	driver.quit();
}
}