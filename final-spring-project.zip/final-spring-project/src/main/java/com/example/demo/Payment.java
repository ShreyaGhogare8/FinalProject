package com.example.demo;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Payment {
	public static void makePayment(WebDriver driver, String email1,String first,String last, String add,String city1,String pin) {
				
		WebElement email = driver.findElement(By.id("email"));
		email.sendKeys(email1);
		WebElement firstname = driver.findElement(By.id("TextField0"));
		WebElement lastName = driver.findElement(By.id("TextField1"));
		WebElement addresss = driver.findElement(By.id("billing-address1"));
		WebElement city = driver.findElement(By.id("TextField3"));
		WebElement pincode = driver.findElement(By.id("TextField4"));
		firstname.sendKeys(first);
		lastName.sendKeys(last);
		addresss.sendKeys(add);
		city.sendKeys(city1);
		pincode.sendKeys(pin);
		WebElement submitButton = driver.findElement(By.xpath("//*[@id=\"pay-button-container\"]/div/div/button"));
		submitButton.click();
	}
}
