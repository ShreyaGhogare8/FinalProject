package com.example.demo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Cart {
	public static void searchAndCart(WebDriver driver, String search ) throws InterruptedException {
		driver.get("https://campus.w3schools.com/en-in/collections/certifications");

		WebElement searchText = driver.findElement(By.xpath("//*[@id=\"shopify-section-static-header\"]/div[2]/div[1]/div[2]/form/div[1]/input"));

//		searching course
		searchText.sendKeys(search);

		
		WebElement searchButton = driver.findElement(By.xpath("//*[@id=\"shopify-section-static-header\"]/div[2]/div[1]/div[2]/form/div[1]/button[2]"));
		searchButton.click();
		System.out.println("clicked");
		System.out.println("cart start");
// adding course to cart
		driver.get("https://campus.w3schools.com/en-in/products/javascript-course?_pos=1&_sid=5da586ecc&_ss=r");
		System.out.println("js clciked");
		WebElement addToCart = driver.findElement(By.xpath("//*[@id=\"product_form_4695230939193\"]/div[2]/button"));
		addToCart.click();
		Thread.sleep(5000);
		WebElement checkout = driver.findElement(By.xpath("//*[@id=\"shopify-section-template--15923756924985__main\"]/form/div[2]/section/div/div/div[3]/button"));
		checkout.click();
		Thread.sleep(8000);
		System.out.println("checkout clicked");
		
		
	}
}
