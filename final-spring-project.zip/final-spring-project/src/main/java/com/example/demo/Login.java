package com.example.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login {
	
	public static void performLogin(WebDriver driver, String username , String password) throws InterruptedException {
		driver.get("https://profile.w3schools.com/log-in");
		driver.manage().window().maximize();
//		 Login into account
		WebElement usernameField = driver.findElement(By.id("modalusername"));
		WebElement passwordField = driver.findElement(By.id("current-password"));
		
		usernameField.sendKeys(username);
		passwordField.sendKeys(password);
		
		WebElement loginButton = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[4]/div[1]/div/div[4]/div[1]/button"));
		loginButton.click();
		

		
	}

}